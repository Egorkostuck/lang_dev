import React from 'react';
import styles from './SignIn.module.css';
import {NavLink} from 'react-router-dom';
import { useForm } from 'react-hook-form';

const SignUp = (props) => {
    
    const {register, handleSubmit, errors} = useForm();

    const validators = {
        required: 'the field can not be empty '
    };
   
    const onSubmit = (value) => {
        const newUser = value;
        const addNewUser = () => {
            props.setUsers([...props.users, newUser]);
            localStorage.setItem('users', JSON.stringify([...props.users, newUser]));
        }    
        if(props.users.length !== 0) {
            props.users.find(item => (item.name === value.name || item.email === value.email) ) ? alert('this name or email is already in use ')  : addNewUser();
            debugger
        } else {
            addNewUser();      
        }
        
    };
    console.log(props.users);
    return(
        <div>
            <NavLink to={'/sign-in'}>
                <div className={styles.containerButtonSignUp}>
                    <button className={styles.buttonSignUp}>Sign in</button>
                </div> 
            </NavLink>
            <form onSubmit={handleSubmit(onSubmit)} className={styles.containerForm}>
                <h3 className={styles.titleLogin}>Sign Up</h3>
                <input className={styles.inputLogin} type="text" name="name" placeholder="Name" ref={register({...validators, minLength: {value: 2, message: 'the field cannot be empty'},maxLength: {value: 10, message: 'no more than 10 characters'}, pattern:{value: /[A-Z]{2,10}/i,  message: 'only Latin'} })}/>
                {errors.name && errors.name.message}
                <input className={styles.inputLogin} type="email" name="email" placeholder="email@example.com" ref={register({...validators, pattern:{value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,  message: 'Invalid email address'} })}/>
                {errors.email && errors.email.message}
                <input className={styles.inputLogin} type="password" name="password" placeholder="password" ref={register({...validators, pattern:{value: /^[A-Z0-9_-]{8,12}$/i,  message: '8 to 12 characters: Latin, numbers, underscore and hyphen'} })}/>
                {errors.password && errors.password.message}    
                <button type="submit" className={styles.buttonLogin}>Sign up</button>
            </form>
        </div>
    )
}

export default SignUp;